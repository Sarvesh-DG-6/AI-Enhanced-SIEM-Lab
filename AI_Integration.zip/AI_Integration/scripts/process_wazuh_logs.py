import json
import csv

with open("/var/ossec/logs/alerts/alerts.json") as f, open("data/parsed_logs.csv", "w", newline='') as out:
    writer = csv.writer(out)
    writer.writerow(["src_port", "dst_port", "event_count", "bytes_sent"])  # customize these

    for line in f:
        try:
            entry = json.loads(line)
            src_port = entry.get("data", {}).get("srcport", 0)
            dst_port = entry.get("data", {}).get("dstport", 0)
            count = entry.get("rule", {}).get("frequency", 1)
            writer.writerow([src_port, dst_port, count, 500])  # default bytes
        except:
            continue
