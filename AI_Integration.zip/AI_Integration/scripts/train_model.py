import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

df = pd.read_csv("data/test_dataset.csv")
features = df[["src_port", "dst_port", "event_count", "bytes_sent"]]

model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
model.fit(features)

joblib.dump(model, "models/isolation_forest_model.pkl")
print("Model trained and saved.")
