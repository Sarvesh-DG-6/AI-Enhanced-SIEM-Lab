import pandas as pd
import joblib

model = joblib.load("models/isolation_forest_model.pkl")
df = pd.read_csv("data/test_dataset.csv")

features = df[["src_port", "dst_port", "event_count", "bytes_sent"]]
df["anomaly"] = model.predict(features)

df.to_csv("data/anomaly_output.csv", index=False)
print(df[df["anomaly"] == -1])  # Show only anomalies
