# AI-Enhanced SIEM Lab
 A Security Information and Event Management Lab built using Ubntu, Kali and Metasplotable VMs, and used AI integration  to train, predict and visualize anomalies in new data
